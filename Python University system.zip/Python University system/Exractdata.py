from select import select
import sqlite3
from tkinter.tix import ROW

c=sqlite3.connect('test.db')
sqlite3.Cursor=c.execute("select * from Student")
cur = sqlite3.Cursor
rows = cur.fetchall()
for row in rows:
    print(row)