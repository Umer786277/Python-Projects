from pydoc import text
import sqlite3

conn=sqlite3.connect('test.db')

conn.execute('''CREATE TABLE Student(
            ID int primary key not null,
            First_Name char(50) not null,
            Last_Name char(50) not null,
            Session char(50));''')


conn.commit()
conn.close()