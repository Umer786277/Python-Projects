import sqlite3
c=sqlite3.connect('new.db')
n=c.cursor()
n.execute("insert into Faculty values(01,'Umer','Farooq','22','CS','Burewala')")
n.execute("insert into Faculty values(02,'Ahsan','Jameel','24','IT','Arifwala')")
n.execute("select * from Faculty where Age=24 and Last_Name='Jameel' ")
print(n.fetchall())
c.commit()
c.close()
