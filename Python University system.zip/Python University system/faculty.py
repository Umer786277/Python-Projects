class Faculty:
    def __init__(self,f_name,l_name,pay) -> None:
        self.f_name=f_name
        self.l_name=l_name
        self.pay=pay
    
    @property
    def mail(self):
        return'{}.{}@mail.com'.format(self.f_name,self.l_name)
    

    @property
    def fullname(self):
        return'{} {}'.format(self.f_name,self.l_name)
    

    def __repr__(self) -> str:
        return"faculty('{}','{}','{}')".format(self.f_name,self.l_name,self.pay)