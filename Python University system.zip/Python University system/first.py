import sqlite3
from employee import Employee
mon=sqlite3.connect('first.db')
n=mon.cursor()
n.execute("""create table Employee(
    Fac_ID int primary key not null,
    First Name text,
    Last_Name text,
    Age int(2),
    Department text(20),
    Address varchar(30));""")


emp_1=Employee('Umer','Farooq',2000)
emp_2=Employee('Kashi','Shehzad',3000)

n.execute("insert into Employee values(?,?,?)",(emp_1.f_name,emp_1.l_name,emp_1.pay))
n.execute("insert into Employee values(:f_name,:l_name,:pay)",{'f_name':emp_2.f_name,'l_name':emp_2.l_name,'pay':emp_2.pay})

n.execute("select * from Employee where f_name='Umer'")
print(n.fetchall())

mon.commit()
mon.close()