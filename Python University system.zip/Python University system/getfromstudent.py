import sqlite3
d=sqlite3.connect('test.db')
dm=d.cursor()
dm.execute("select * from Student where Last_Name='Arshad'")
dm.execute("select * from Student where First_Name='Naeem' and Last_Name='Ameer'")
print(dm.fetchone())
d.commit()
d.close()
