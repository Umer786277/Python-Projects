import sqlite3
con = sqlite3.connect('test.db')
con.execute("insert into Student(ID,First_Name,Last_Name,Session) \
            values(02,'Umair','Arshad','BSIT')");
con.execute("insert into Student(ID,First_Name,Last_Name,Session) \
            values(03,'Naeem','Ameer','BSSE')");




con.commit()
con.close()
            