import sqlite3
from faculty import Faculty
mon=sqlite3.connect('new.db')
n=mon.cursor()
n.execute("""create table Faculty(
    Fac_ID int primary key not null,
    First Name text,
    Last_Name text,
    Age int(2),
    Department text(20),
    Address varchar(30));""")


emp_1=Faculty('Umer','Farooq',2000)
emp_2=Faculty('Kashi','Shehzad',3000)

n.execute("insert into Faculty values(?,?,?)",(emp_1.f_name,emp_1.l_name,emp_1.pay))
n.execute("insert into Faculty values(:f_name,:l_name,:pay)",{'f_name':emp_2.f_name,'l_name':emp_2.l_name,'pay':emp_2.pay})

n.execute("select * from Faculty where f_name='Umer'")
print(n.fetchall())

mon.commit()
mon.close()